// app.config.ts
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations'; // ← Correct spelling
import { routes } from './app.routes'; // ← Import routes from app.routes.ts

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes), // ← Routes go inside provideRouter()
    provideAnimations(),   // ← This enables animations
    // Other providers if needed
  ]
};