import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,  // ← ADD THIS if you're using standalone components
  imports: [RouterOutlet],  // ← Only RouterOutlet is needed here
  templateUrl: './app.html',  // ← Changed from './app.component.html'
  styleUrls: ['./app.css']  // ← Changed from './app.component.css'
})
export class App {
  title = 'my-app';
  
  // Remove the constructor - it's not needed
  // Header and Profile should be loaded via routing, not here
}