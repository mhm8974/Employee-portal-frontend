import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { interval, Subscription } from 'rxjs';
import {
  trigger,
  transition,
  animate,
  keyframes,
  style
} from '@angular/animations';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
  animations: [
    trigger('shake', [
      transition('* => shake', [
        animate(
          '350ms',
          keyframes([
            style({ transform: 'translateX(0)', offset: 0 }),
            style({ transform: 'translateX(-6px)', offset: 0.2 }),
            style({ transform: 'translateX(6px)', offset: 0.4 }),
            style({ transform: 'translateX(-6px)', offset: 0.6 }),
            style({ transform: 'translateX(6px)', offset: 0.8 }),
            style({ transform: 'translateX(0)', offset: 1 })
          ])
        )
      ])
    ])
  ]
})
export class DashboardComponent implements OnInit, OnDestroy {

  generatedOtp = '';
  otpBoxes: string[] = ['', '', '', '', '', ''];

  expiryTime!: number;
  remainingTime = 0;

  timerSub!: Subscription;
  errorMessage = '';

  // 🔴 animation state
  shakeState: 'idle' | 'shake' = 'idle';

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.generateOtp();
    this.setExpiry();
    this.startLiveTimer();
  }

  ngOnDestroy(): void {
    this.timerSub?.unsubscribe();
  }

  trackByIndex(index: number): number {
    return index;
  }

  generateOtp(): void {
    this.generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    console.log('OTP:', this.generatedOtp);
  }

  setExpiry(): void {
    this.expiryTime = Date.now() + 60 * 1000;
  }

  startLiveTimer(): void {
    this.timerSub?.unsubscribe();

    this.timerSub = interval(1000).subscribe(() => {
      const diff = Math.floor((this.expiryTime - Date.now()) / 1000);
      this.remainingTime = diff > 0 ? diff : 0;
    });
  }

  handleInput(event: KeyboardEvent, index: number): void {
    const input = event.target as HTMLInputElement;

    if (event.key === 'Backspace') {
      event.preventDefault();
      
      // Find the last filled box
      const lastFilledIndex = this.findLastFilledIndex();
      
      // Only allow delete from the last filled box
      if (index !== lastFilledIndex && lastFilledIndex !== -1) {
        // Move focus to the last filled box
        const lastInput = document.getElementById(`otp-${lastFilledIndex}`) as HTMLInputElement;
        if (lastInput) {
          lastInput.focus();
        }
        return;
      }
      
      // If deleting from the last filled box
      if (lastFilledIndex !== -1) {
        input.value = '';
        this.otpBoxes[lastFilledIndex] = '';
        
        if (lastFilledIndex > 0) {
          // Enable and focus on previous box
          const prevInput = document.getElementById(`otp-${lastFilledIndex - 1}`) as HTMLInputElement;
          if (prevInput) {
            prevInput.disabled = false;
            prevInput.focus();
          }
        }
      }
      return;
    }

    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
      return;
    }

    event.preventDefault();
    input.value = event.key;
    this.otpBoxes[index] = event.key;

    if (index < 5) {
      // Enable the next box
      const nextInput = document.getElementById(`otp-${index + 1}`) as HTMLInputElement;
      if (nextInput) {
        nextInput.disabled = false;
        nextInput.focus();
      }
    }
  }

  // Helper method to find the last filled box index
  private findLastFilledIndex(): number {
    for (let i = this.otpBoxes.length - 1; i >= 0; i--) {
      if (this.otpBoxes[i] !== '') {
        return i;
      }
    }
    return -1; // No boxes are filled
  }

  // 🔥 TRIGGER ANGULAR SHAKE
  triggerShake(): void {
    this.shakeState = 'idle';
    setTimeout(() => {
      this.shakeState = 'shake';
    }, 0);
  }

  verifyOtp(): void {
    const enteredOtp = this.otpBoxes.join('');

    if (this.remainingTime === 0) {
      this.errorMessage = 'OTP expired';
      this.triggerShake();
      return;
    }

    if (enteredOtp !== this.generatedOtp) {
      this.errorMessage = 'Invalid OTP';
      this.triggerShake();
      return;
    }

    this.router.navigate(['/secure']);
  }

  resendOtp(): void {
    if (this.remainingTime > 0) return;

    this.generateOtp();
    this.setExpiry();
    this.startLiveTimer();
    this.otpBoxes = ['', '', '', '', '', ''];
    this.errorMessage = '';
    
    // Reset all inputs to disabled state (except first one)
    setTimeout(() => {
      for (let i = 0; i < 6; i++) {
        const input = document.getElementById(`otp-${i}`) as HTMLInputElement;
        if (input) {
          input.disabled = i > 0;
          input.value = '';
        }
      }
      
      // Focus on first input
      const firstInput = document.getElementById('otp-0') as HTMLInputElement;
      if (firstInput) {
        firstInput.focus();
      }
    }, 0);
  }
}