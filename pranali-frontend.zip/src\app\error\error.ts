import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-error',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div style="height:100vh;display:flex;flex-direction:column;
                justify-content:center;align-items:center;
                background:#f8d7da;color:#721c24;">
      <h2>Invalid CPF / GPF / Employee ID</h2>
      <p>You are not authorized to access PRANALI.</p>
      <a href="/profile">Go back to Login</a>
    </div>
  `
})
export class ErrorComponent {}
