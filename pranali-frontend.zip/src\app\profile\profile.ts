import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  trigger,
  state,
  style,
  transition,
  animate,
  keyframes
} from '@angular/animations';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.css'],
  animations: [
    trigger('shake', [
      state('false', style({ transform: 'translateX(0)' })),
      state('true', style({ transform: 'translateX(0)' })),
      transition('false <=> true', [
        animate('0.5s', keyframes([
          style({ transform: 'translateX(0)', offset: 0 }),
          style({ transform: 'translateX(-10px)', offset: 0.1 }),
          style({ transform: 'translateX(10px)', offset: 0.2 }),
          style({ transform: 'translateX(-10px)', offset: 0.3 }),
          style({ transform: 'translateX(10px)', offset: 0.4 }),
          style({ transform: 'translateX(-10px)', offset: 0.5 }),
          style({ transform: 'translateX(10px)', offset: 0.6 }),
          style({ transform: 'translateX(-10px)', offset: 0.7 }),
          style({ transform: 'translateX(10px)', offset: 0.8 }),
          style({ transform: 'translateX(-10px)', offset: 0.9 }),
          style({ transform: 'translateX(0)', offset: 1 })
        ]))
      ])
    ])
  ]
})
export class Profile {
  employeeId = '';
  captcha = '';
  captchaInput = '';

  showIdError = false;
  errorMessage = '';

  // SHAKE ANIMATION TRIGGER
  shakeTrigger = false;
  
  // ✅ Track if this is a fresh login attempt
  private freshLogin = true;
  
  // ✅ Loading state
  isLoading = false;

  constructor(
    private router: Router
  ) {
    // Generate captcha only on fresh login
    if (this.freshLogin) {
      this.generateCaptcha();
      this.freshLogin = false;
    }
  }

  generateCaptcha(): void {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    this.captcha = '';
    for (let i = 0; i < 5; i++) {
      this.captcha += chars[Math.floor(Math.random() * chars.length)];
    }
  }

  validateId(): void {
    this.showIdError = this.employeeId.trim() === '';
  }

  // ✅ triggers shake animation
  triggerShake(): void {
    this.shakeTrigger = !this.shakeTrigger;
    this.errorMessage = '';
  }

  login(): void {
    // Reset states
    this.errorMessage = '';
    this.showIdError = false;
    this.isLoading = true; // ✅ Show loading
    
    // ❌ CPF / GPF empty - SHAKE ONLY (NO ERROR MESSAGE)
    if (this.employeeId.trim() === '') {
      this.showIdError = true;
      this.triggerShake(); // ← SHAKE ONLY
      this.isLoading = false;
      return; // ⛔ STOP here
    }

    // ❌ Captcha mismatch - SHAKE ONLY (NO ERROR MESSAGE)
    if (this.captchaInput.trim().toUpperCase() !== this.captcha) {
      // NO ERROR MESSAGE HERE - JUST SHAKE
      this.captchaInput = '';
      this.triggerShake(); // ← SHAKE ONLY
      this.isLoading = false;
      return; // ⛔ STOP here
    }

    // ✅ SUCCESS (only reaches here if NO errors)
    this.shakeTrigger = false;
    this.errorMessage = ''; // Clear any leftover errors

    // Set freshLogin to true so next time we come back, captcha changes
    this.freshLogin = true;

    // Simulate API delay
    setTimeout(() => {
      this.isLoading = false;
      
      // Store employee ID in localStorage for session
      localStorage.setItem('employeeId', this.employeeId);
      
      console.log('Login successful. Navigating to dashboard...');
      
      // ✅ DIRECTLY navigate to dashboard after successful captcha verification
      this.router.navigate(['/dashboard']);
    }, 1000);
  }

  // ✅ Reset for when user comes back to login page
  resetForNewLogin(): void {
    this.employeeId = '';
    this.captchaInput = '';
    this.errorMessage = '';
    this.showIdError = false;
    this.shakeTrigger = false;
    this.isLoading = false;

    // Only generate new captcha if it's a fresh login
    if (this.freshLogin) {
      this.generateCaptcha();
      this.freshLogin = false;
    }
  }

  // ✅ Check if user is logged in
  isLoggedIn(): boolean {
    return localStorage.getItem('employeeId') !== null;
  }

  // ✅ Get stored employee ID
  getStoredEmployeeId(): string | null {
    return localStorage.getItem('employeeId');
  }

  // ✅ Logout
  logout(): void {
    localStorage.removeItem('employeeId');
    this.resetForNewLogin();
  }
}