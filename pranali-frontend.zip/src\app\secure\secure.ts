import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService, UserProfile } from '../services/auth.service';
import { catchError, of } from 'rxjs';

// Interface for employee data from backend - Use the same as AuthService
export interface EmployeeData extends UserProfile {
  // All fields already in UserProfile
}

export interface PaySlipData {
  id: number;
  employee_id: string;
  year: number;
  month: string;
  pay_period: string;
  basic_salary: number;
  house_rent_allowance: number;
  travel_allowance: number;
  medical_allowance: number;
  special_allowance: number;
  provident_fund: number;
  professional_tax: number;
  income_tax: number;
  other_deductions: number;
  gross_salary: number;
  total_deductions: number;
  net_salary: number;
  payment_date?: string;
  status: string; // 'paid', 'pending', 'processing'
}

export interface FastAPIResponse<T> {
  data: T;
  message: string;
  success: boolean;
}

@Component({
  selector: 'app-secure',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './secure.html',
  styleUrls: ['./secure.css']
})
export class SecureComponent implements OnInit {
  years = [2026, 2025, 2024, 2023, 2022, 2021, 2020];
  months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  selectedYear = 2026;
  selectedMonth = 'January';
  
  // Employee data from FastAPI backend
  employeeData: EmployeeData | null = null;
  paySlipData: PaySlipData | null = null;
  
  // Loading states
  isLoading = false;
  isPayslipLoading = false;
  
  // Error handling
  errorMessage = '';

  // ✅ BACKEND URL - Update this to your FastAPI URL
  private apiUrl = 'http://localhost:8000'; // FastAPI usually runs on 8000

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    // Load employee data when component initializes
    this.loadEmployeeData();
    
    // Load payslip data for default month/year
    this.loadPaySlipData();
  }

  // Load employee profile data from FastAPI backend
  loadEmployeeData(): void {
    this.isLoading = true;
    this.errorMessage = '';

    // Use AuthService to get employee data
    this.authService.getEmployeeData()
      .pipe(
        catchError(error => {
          console.error('Error loading employee data:', error);
          this.errorMessage = this.getErrorMessage(error);
          this.isLoading = false;
          
          // Fallback to localStorage data
          this.loadFromLocalStorage();
          return of(null);
        })
      )
      .subscribe({
        next: (data) => {
          if (data) {
            this.employeeData = data as EmployeeData;
            
            // Create full name if not provided
            if (!this.employeeData.full_name) {
              this.employeeData.full_name = `${this.employeeData.first_name} ${this.employeeData.last_name}`;
            }
            
            console.log('Employee data loaded from FastAPI:', this.employeeData);
          }
          this.isLoading = false;
        }
      });
  }

  // Load payslip data for selected month/year
  loadPaySlipData(): void {
    this.isPayslipLoading = true;
    
    const token = this.authService.getToken();
    if (!token) {
      this.isPayslipLoading = false;
      return;
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    // FastAPI endpoint for payslip
    const params = {
      year: this.selectedYear.toString(),
      month: this.selectedMonth.toLowerCase()
    };

    this.http.get<FastAPIResponse<PaySlipData>>(`${this.apiUrl}/api/payslips`, { 
      headers,
      params 
    })
      .pipe(
        catchError(error => {
          console.error('Error loading payslip data:', error);
          this.isPayslipLoading = false;
          return of(null);
        })
      )
      .subscribe({
        next: (response) => {
          if (response && response.success) {
            this.paySlipData = response.data;
            console.log('Payslip data loaded:', this.paySlipData);
          }
          this.isPayslipLoading = false;
        }
      });
  }

  // Get error message from FastAPI error response
  private getErrorMessage(error: any): string {
    if (error.error?.detail) {
      // FastAPI returns errors in .detail
      return Array.isArray(error.error.detail) 
        ? error.error.detail.map((d: any) => d.msg).join(', ')
        : error.error.detail;
    }
    if (error.error?.message) {
      return error.error.message;
    }
    if (error.status === 0) {
      return 'Cannot connect to server. Please check if FastAPI is running.';
    }
    if (error.status === 401) {
      return 'Session expired. Please login again.';
    }
    if (error.status === 404) {
      return 'Employee data not found.';
    }
    return error.message || 'An error occurred';
  }

  // Fallback: Load from localStorage if API fails
  private loadFromLocalStorage(): void {
    const userData = this.authService.getUserData();
    if (userData) {
      this.employeeData = userData as EmployeeData;
      console.log('Loaded employee data from localStorage:', this.employeeData);
    }
  }

  // Handle month/year selection change
  onSelectionChange(): void {
    this.loadPaySlipData();
  }

  // Format date for display (DD - MM - YYYY) - matches your design
  formatDate(dateString?: string): string {
    if (!dateString) return 'N/A';
    
    try {
      // Parse date (FastAPI returns as string)
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return dateString; // Return as-is if invalid
      }
      
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      return `${day} - ${month} - ${year}`;
    } catch (error) {
      return dateString;
    }
  }

  // ========== NULL-SAFE GETTER METHODS ==========

  // Get birth date for date input (YYYY-MM-DD format)
  get birthDate(): string {
    if (!this.employeeData?.date_of_birth) return '';
    
    try {
      const date = new Date(this.employeeData.date_of_birth);
      if (isNaN(date.getTime())) {
        return this.employeeData.date_of_birth || '';
      }
      return date.toISOString().split('T')[0];
    } catch (error) {
      return this.employeeData.date_of_birth || '';
    }
  }

  // Get employee full name
  get employeeFullName(): string {
    if (!this.employeeData) return 'N/A';
    return this.employeeData.full_name || 
           `${this.employeeData.first_name || ''} ${this.employeeData.last_name || ''}`.trim() || 'N/A';
  }

  // Get employee ID
  get employeeId(): string {
    if (!this.employeeData) return 'N/A';
    return this.employeeData.employee_id || 'N/A';
  }

  // Get department
  get department(): string {
    if (!this.employeeData) return 'N/A';
    return this.employeeData.department || 'N/A';
  }

  // Get position
  get position(): string {
    if (!this.employeeData) return 'N/A';
    return this.employeeData.position || 'N/A';
  }

  // Get pay period
  get payPeriod(): string {
    return `${this.selectedMonth} ${this.selectedYear}`;
  }

  // Get status badge text
  get statusText(): string {
    if (!this.employeeData?.status) return 'Active';
    return this.employeeData.status.charAt(0).toUpperCase() + 
           this.employeeData.status.slice(1);
  }

  // Get status badge class
  get statusClass(): string {
    if (!this.employeeData?.status) return 'status-active';
    
    const status = this.employeeData.status.toLowerCase();
    switch (status) {
      case 'active': return 'status-active';
      case 'inactive': return 'status-inactive';
      case 'on_leave': return 'status-leave';
      default: return 'status-active';
    }
  }

  // Calculate total allowances (if payslip data available)
  get totalAllowances(): number {
    if (!this.paySlipData) return 0;
    return (this.paySlipData.house_rent_allowance || 0) +
           (this.paySlipData.travel_allowance || 0) +
           (this.paySlipData.medical_allowance || 0) +
           (this.paySlipData.special_allowance || 0);
  }

  // Calculate total deductions (if payslip data available)
  get totalDeductions(): number {
    if (!this.paySlipData) return 0;
    return (this.paySlipData.provident_fund || 0) +
           (this.paySlipData.professional_tax || 0) +
           (this.paySlipData.income_tax || 0) +
           (this.paySlipData.other_deductions || 0);
  }

  // Download payslip PDF
  downloadPayslip(): void {
    this.isPayslipLoading = true;
    const token = this.authService.getToken();
    
    if (!token) {
      this.isPayslipLoading = false;
      alert('Please login to download payslip');
      return;
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    const params = {
      year: this.selectedYear.toString(),
      month: this.selectedMonth.toLowerCase(),
      format: 'pdf'
    };

    // FastAPI endpoint for PDF download
    this.http.get(`${this.apiUrl}/api/payslips/download`, { 
      headers,
      params,
      responseType: 'blob' // Important for file download
    })
      .pipe(
        catchError(error => {
          console.error('Error downloading payslip:', error);
          this.isPayslipLoading = false;
          alert(`Download failed: ${this.getErrorMessage(error)}`);
          return of(null);
        })
      )
      .subscribe({
        next: (blob) => {
          if (blob) {
            this.isPayslipLoading = false;
            
            // Create download link
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `payslip_${this.employeeId}_${this.selectedMonth}_${this.selectedYear}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
          }
        }
      });
  }

  // Format currency for Indian Rupees
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }

  // ========== HELPER METHODS FOR TEMPLATE ==========

  // Check if employee data exists (for template)
  hasEmployeeData(): boolean {
    return !!this.employeeData;
  }

  // Check if payslip data exists (for template)
  hasPaySlipData(): boolean {
    return !!this.paySlipData;
  }

  // Get first name safely
  getFirstName(): string {
    return this.employeeData?.first_name || 'N/A';
  }

  // Get last name safely
  getLastName(): string {
    return this.employeeData?.last_name || 'N/A';
  }

  // Get formatted date of birth
  getFormattedDOB(): string {
    return this.formatDate(this.employeeData?.date_of_birth);
  }
}