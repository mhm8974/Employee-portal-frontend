import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  templateUrl: './header.html',
  styleUrls: ['./header.css']
})
export class Header {
  isLoggedIn = false;

  menuItems = ['Home', 'Profile', 'Settings'];

  toggleLogin() {
    this.isLoggedIn = !this.isLoggedIn;
  }

}
