import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-secure',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './secure.html',
  styleUrls: ['./secure.css']
})
export class SecureComponent {
  years = [2026, 2025, 2024, 2023, 2022, 2021, 2020];
  months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  selectedYear = 2026;
  selectedMonth = 'January';
  birthDate = '2003-11-07'; // ISO format for date input
}